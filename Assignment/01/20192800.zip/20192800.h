void signed_char(char*, uint8_t);
void ASCII_codes(char*, uint8_t);
void unsigned_char(unsigned char*, uint8_t);
void signed_int(int*, uint32_t);
void unsigned_int(unsigned int*, uint32_t);
void signed_float(float*, int32_t);
void signed_double(double*, int64_t);
